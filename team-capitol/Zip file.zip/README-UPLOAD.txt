SHOWVIVA — CLARE & RIKKI / CAPITOL STUD IPHONE PWA

TARGET FOLDER
Upload these files into:
Rikki-Claire/prepare-test/

FILES
- index.html (PWA-enabled copy of the Capitol Stud test planner)
- manifest.json
- service-worker.js
- icons/showviva-icon-180.png
- icons/showviva-icon-192.png
- icons/showviva-icon-512.png

IMPORTANT
- Keep planner.html and any other existing files in prepare-test unchanged.
- The app still uses the private team fragment link.
- After upload, open the full private URL in Safari, remove the old Home Screen shortcut, then Share > Add to Home Screen again.
- The PWA manifest starts with the private team fragment so the installed app opens the Clare & Rikki team experience.
- The service worker caches only the local app shell; live Supabase/API traffic remains live.
